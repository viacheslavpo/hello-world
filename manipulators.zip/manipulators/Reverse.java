package manipulators;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class Reverse {
	public void manipulate(List<String> rows){
		
//		Collections.reverse(rows);
		List<String> reversed = new ArrayList<String>(rows.size());
		for(int i=rows.size()-1;i>=0;i--){
			reversed.add(rows.get(i));
		}
		rows.clear();
		rows.addAll(reversed);
	}
}
