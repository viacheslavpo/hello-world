package manipulators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Shuffle {
	public void manipulate(List<String> lines){
		
//		Collections.shuffle(lines);
		Random rand = new Random();
		List<String> shuffled = new ArrayList<String>(lines.size());
		while(lines.size()>0){
			int index = rand.nextInt(lines.size());
			shuffled.add(lines.get(index));
			lines.remove(index);
		}
		lines.addAll(shuffled);
	}
}
