package manipulators;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sort {
	public void manipulate(List<String> lines){
		
//		Collections.sort(lines);
		List<String> sorted = mergesort(lines);
		lines.clear();
		lines.addAll(sorted);
	}
	
	private List<String> mergesort(List<String> lines){
		if(lines.size()==0 || lines.size()==1){
			return lines;
		}
		List<String> left = mergesort(lines.subList(0, lines.size()/2));
		List<String> right = mergesort(lines.subList(lines.size()/2,lines.size() ));
		return merge(left,right);
	}

	private List<String> merge(List<String> left, List<String> right) {
		List<String> toreturn = new ArrayList<String>();
		int i=0;
		int j=0;
		while(i<left.size() && j<right.size()){
			if(left.get(i).compareTo(right.get(j)) < 0){
				toreturn.add(left.get(i++));
			} else{
				toreturn.add(right.get(j++));
			}
		}
		while(i<left.size())
			toreturn.add(left.get(i++));
		while(j<right.size())
			toreturn.add(right.get(j++));
		return toreturn;
	}
}
